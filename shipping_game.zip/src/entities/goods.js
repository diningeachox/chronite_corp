// Might need to use the full Entity system for this

const goods = {
  metal: {name: "Metal"},
  chronium: {name: "Chronium"},
  ships: {name: "Ships"},
  hp: {name: "HP"},
  gold: {name: "Gold"},
  pyrite: {name: "Pyrite"},
  deuterium: {name: "Deuterium"}
}

export default goods;