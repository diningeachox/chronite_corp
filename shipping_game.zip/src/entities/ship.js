import {ShipFactory} from "../assets.js";
import {Vector2D} from "../vector2D.js";

const ship = (config) => {
    const ent = new ECS.Entity();
    ent.addComponent( new ECS.Components.Position(config.position || new Vector2D(0, 0)));
    ent.addComponent( new ECS.Components.HP(config.hp));
    ent.addComponent( new ECS.Components.Speed(config.speed));
    ent.addComponent( new ECS.Components.Capacity(config.capacity));
    //ent.addComponent( new ECS.Components.Lane(config.lane));
    var uuid = ShipFactory(ent.components.position.value.x, ent.components.position.value.y);
    matching_entity[uuid] = ent;
    return ent;
}

//Ship types
const basic_ship = (x, y) => {ship({position: new Vector2D(x, y), hp: 100, speed: 1.0, capacity: 5})};
const tanker = (x, y) => {ship({position: new Vector2D(x, y), hp: 500, speed: 0.2, capacity: 30})}; //Massive and slow but can store a lot

const fleet = (config) => {
    const ent = new ECS.Entity();
    ent.addComponent( new ECS.Components.Position(config.position || new Vector2D(0, 0)));
    ent.addComponent( new ECS.Components.Ships(config.ships)); //This is an array

    //A fleet is only as fast as its slowest ship
    var min_speed = Infinity;
    for (var i = 0; i < config.ships.length; i++){
        min_speed = Math.min(config.ships[i].components.value.speed, min_speed);
    }
    ent.addComponent( new ECS.Components.Speed(min_speed));
    ent.addComponent( new ECS.Components.Lane(config.lane));
    return ent;
}

export {basic_ship, tanker, fleet};
