import * as Assets from "./assets.js";
import {Scene} from "./scenes.js";
var c = Assets.c;
